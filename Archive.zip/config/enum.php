<?php
    return [
        'STATUS' => [
            'ACTIVE',
            'INACTIVE'
        ]
    ];
?>